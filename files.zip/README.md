# Cheminformatics Virtual Lab

An interactive website for learning cheminformatics. Type a molecule as a SMILES string and see its 2D structure, calculated properties and drug-likeness instantly.

## Pages
- **Home** – live SMILES input and structure drawing
- **Theory** – SMILES, descriptors, Lipinski's rule of five, structure–property relationships
- **Molecular Visualization** – validate SMILES, draw the structure, add it to your notebook
- **Molecular Properties Report** – formula, molecular weight, logP, H-bond donors/acceptors, TPSA, rotatable bonds, rings
- **Structure–Property Analysis** – scatter plot and comparison table for your notebook molecules
- **Assessment** – five-question quiz with feedback
- **Final Project Report** – student details, molecule table and observations; print or copy

## Run locally
No build step or dependencies. Open `index.html` in a browser.

## Deploy with GitHub Pages
1. Push these files to a GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site appears at `https://<your-username>.github.io/<repo-name>/`.

## Notes
- Includes its own lightweight SMILES parser (no RDKit), so drawings are auto-arranged and logP/TPSA are simple estimates.
- Student details, notebook molecules and report notes are saved in the browser's localStorage.
- Fonts (Fraunces, Instrument Sans) load from Google Fonts.

## Files
| File | Purpose |
|------|---------|
| `index.html` | Page shell |
| `style.css` | Styles, light and dark themes |
| `app.js` | SMILES parser, property calculations, drawing, pages |

const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const MASS={C:12.011,N:14.007,O:15.999,S:32.06,P:30.974,F:18.998,Cl:35.45,Br:79.904,I:126.904,B:10.81,H:1.008};
const VAL={B:[3],C:[4],N:[3,5],O:[2],P:[3,5],S:[2,4,6],F:[1],Cl:[1],Br:[1],I:[1]};
const COL={N:'#3b6fd8',O:'#d6342c',S:'#b88a00',F:'#2f9e44',Cl:'#2f9e44',Br:'#a05a2c',P:'#e07b00',I:'#7b3fa0',B:'#c06a8a'};
const EX={Aspirin:'CC(=O)Oc1ccccc1C(=O)O',Caffeine:'Cn1cnc2c1c(=O)n(C)c(=O)n2C',Ibuprofen:'CC(C)Cc1ccc(cc1)C(C)C(=O)O',Paracetamol:'CC(=O)Nc1ccc(O)cc1',Ethanol:'CCO',Benzene:'c1ccccc1',Cholesterol:'CC(C)CCCC(C)C1CCC2C1(CCC3C2CC=C4C3(CCC(C4)O)C)C'};
let S={cur:EX.Aspirin,mols:['Aspirin','Caffeine','Ibuprofen','Paracetamol','Ethanol'].map(n=>({n,s:EX[n]})),stu:{n:'',r:''},notes:''};
try{const d=JSON.parse(localStorage.getItem('vl'));if(d){S.mols=d.mols||S.mols;S.stu=d.stu||S.stu;S.notes=d.notes||''}}catch(e){}
const save=()=>{try{localStorage.setItem('vl',JSON.stringify({mols:S.mols,stu:S.stu,notes:S.notes}))}catch(e){}};

function parse(s){
 s=s.trim();if(!s)throw'Type a SMILES string to begin.';
 const A=[],B=[],st=[],R={};let prev=null,bond=null,i=0;
 const add=(el,ar,h,br,q)=>{const a={el,ar,h,br,q:q||'',i:A.length};A.push(a);if(prev!==null)B.push([prev,a.i,bond||(ar&&A[prev].ar?1.5:1)]);prev=a.i;bond=null};
 while(i<s.length){const c=s[i];let m;
  if(c=='['){const j=s.indexOf(']',i);if(j<0)throw'A [ bracket is never closed.';
   m=s.slice(i+1,j).match(/^\d*([A-Z][a-z]?|[bcnops])@*(?:H(\d?))?([+-]\d*)?$/);if(!m)throw'Unsupported bracket atom '+s.slice(i,j+1)+'.';
   let el=m[1],ar=el==el.toLowerCase();el=el[0].toUpperCase()+el.slice(1);if(!MASS[el])throw'Unknown element '+el+'.';
   add(el,ar,m[2]===undefined?0:m[2]===''?1:+m[2],1,m[3]);i=j+1;continue}
  m=s.slice(i).match(/^(Cl|Br|[BCNOPSFI]|[bcnops])/);
  if(m){let el=m[1],ar=el==el.toLowerCase();add(el[0].toUpperCase()+el.slice(1),ar,0,0);i+=el.length;continue}
  if('-=#:'.includes(c))bond={'-':1,'=':2,'#':3,':':1.5}[c];
  else if(c=='/'||c=='\\'){}
  else if(c=='(')st.push(prev);
  else if(c==')'){if(!st.length)throw'A ) has no matching (.';prev=st.pop()}
  else if(c=='.')prev=null;
  else if(/\d|%/.test(c)){let k=c;if(c=='%'){k=s.substr(i,3);i+=2}
   if(prev===null)throw'Ring number '+k+' needs an atom before it.';
   if(R[k]){const r=R[k];B.push([r.a,prev,bond||r.o||(A[r.a].ar&&A[prev].ar?1.5:1)]);delete R[k]}else R[k]={a:prev,o:bond};bond=null}
  else throw'Unexpected character “'+c+'” at position '+(i+1)+'.';
  i++}
 if(st.length)throw'A ( bracket is never closed.';
 const open=Object.keys(R);if(open.length)throw'Ring '+open[0]+' is opened but never closed.';
 A.forEach(a=>{if(a.br)return;let u=0;B.forEach(b=>{if(b[0]==a.i||b[1]==a.i)u+=b[2]});const c=Math.ceil(u-1e-9),v=VAL[a.el],x=v.find(q=>q>=c);
  if(x===undefined){if(!a.ar)throw'Atom '+a.el+' (number '+(a.i+1)+') has too many bonds.';a.h=0}else a.h=x-c});
 return{A,B}}

function cyc(idx,Bs){const p={};const f=x=>p[x]==x?x:(p[x]=f(p[x]));idx.forEach(x=>p[x]=x);let c=idx.length;Bs.forEach(b=>{const u=f(b[0]),v=f(b[1]);if(u!=v){p[u]=v;c--}});return Bs.length-idx.length+c}
function props(m){const{A,B}=m,deg=A.map(()=>0);B.forEach(b=>{deg[b[0]]++;deg[b[1]]++});
 let cnt={},H=0,mw=0,hbd=0,hba=0,tp=0,lp=0;
 A.forEach(a=>{cnt[a.el]=(cnt[a.el]||0)+1;H+=a.h;mw+=MASS[a.el]+a.h*MASS.H;const dbl=B.some(b=>(b[0]==a.i||b[1]==a.i)&&b[2]==2);
  if(a.el=='C')lp+=(a.ar?.15:.2)+.18*a.h;else lp+=a.h*-.2;
  if(a.el=='N'||a.el=='O'){hba++;if(a.h)hbd++}
  if(a.el=='O')tp+=a.h?20.2:dbl?17.1:9.2;if(a.el=='N')tp+=a.ar?12.9:a.h>1?26:a.h?12:3.2;
  lp+={N:-.7,O:-.5,S:.4,F:.3,Cl:.65,Br:.85,I:1.1}[a.el]||0});
 let rot=0;B.forEach((b,k)=>{if(b[2]!=1||deg[b[0]]<2||deg[b[1]]<2)return;const seen={[b[0]]:1},q=[b[0]];while(q.length){const x=q.pop();B.forEach((e,j)=>{if(j==k)return;const y=e[0]==x?e[1]:e[1]==x?e[0]:-1;if(y>=0&&!seen[y]){seen[y]=1;q.push(y)}})}if(!seen[b[1]])rot++});
 const ab=B.filter(b=>b[2]==1.5),ai=[...new Set(ab.flat().filter((x,j)=>j<0||true))];
 const keys=Object.keys(cnt).sort(),ord=(cnt.C?['C',...(H?['H']:[]),...keys.filter(k=>k!='C')]:[...keys,...(H?['H']:[])].sort());
 const all={...cnt,H};const formula=ord.map(k=>k+(all[k]>1?all[k]:'')).join('');
 const o={formula,mw:mw,logp:lp,hbd,hba,tpsa:tp,rot,rings:cyc(A.map((_,i)=>i),B),arom:ab.length?cyc(ai,ab):0,heavy:A.length};
 o.viol=[mw>500,lp>5,hbd>5,hba>10].filter(Boolean).length;return o}

function svg(m){const n=m.A.length;const P=m.A.map((_,i)=>({x:Math.cos(i*2.4)*(1+i*.25),y:Math.sin(i*2.4)*(1+i*.25)}));
 for(let t=0;t<600;t++){const F=P.map(()=>[0,0]);
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){const dx=P[i].x-P[j].x,dy=P[i].y-P[j].y,d=Math.hypot(dx,dy)+.05,k=.5/(d*d);F[i][0]+=dx/d*k;F[i][1]+=dy/d*k;F[j][0]-=dx/d*k;F[j][1]-=dy/d*k}
  m.B.forEach(([a,b])=>{const dx=P[b].x-P[a].x,dy=P[b].y-P[a].y,d=Math.hypot(dx,dy)||.05,k=(d-1)*.6;F[a][0]+=dx/d*k;F[a][1]+=dy/d*k;F[b][0]-=dx/d*k;F[b][1]-=dy/d*k});
  const s=.25*(1-t/600)+.02;P.forEach((p,i)=>{p.x+=Math.max(-.1,Math.min(.1,F[i][0]*s));p.y+=Math.max(-.1,Math.min(.1,F[i][1]*s))})}
 const xs=P.map(p=>p.x),ys=P.map(p=>p.y),x0=Math.min(...xs),y0=Math.min(...ys),w=Math.max(...xs)-x0||1,h=Math.max(...ys)-y0||1,sc=Math.min(60,480/w,290/h);
 const X=p=>280+(p.x-x0-w/2)*sc,Y=p=>180+(p.y-y0-h/2)*sc;let o='<svg viewBox="0 0 560 360" role="img" aria-label="Molecule drawing"><g stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none">';
 m.B.forEach(([a,b,k])=>{const x1=X(P[a]),y1=Y(P[a]),x2=X(P[b]),y2=Y(P[b]),d=Math.hypot(x2-x1,y2-y1)||1,nx=-(y2-y1)/d,ny=(x2-x1)/d;
  const ln=(f,da)=>`<line x1="${x1+nx*f}" y1="${y1+ny*f}" x2="${x2+nx*f}" y2="${y2+ny*f}"${da?' stroke-dasharray="4 4"':''}/>`;
  o+=k==2?ln(-2.8)+ln(2.8):k==3?ln(0)+ln(-4.5)+ln(4.5):k==1.5?ln(0)+ln(5,1):ln(0)});
 o+='</g>';m.A.forEach((a,i)=>{const lab=a.el=='C'&&(n>1||a.h==0)&&!a.q?'':a.el+(a.h?'H'+(a.h>1?a.h:''):'')+(a.q||'');if(!lab&&a.el=='C'&&n==1)return;if(lab)o+=`<circle cx="${X(P[i])}" cy="${Y(P[i])}" r="${9+lab.length*2}" fill="var(--card)"/><text x="${X(P[i])}" y="${Y(P[i])+5}" text-anchor="middle" font-size="15" font-weight="600" fill="${COL[a.el]||'currentColor'}">${esc(lab)}</text>`});
 return o+'</svg>'}

const f1=(x,d=2)=>x.toFixed(d);
const pills=p=>`<div class="pills"><span><b>${p.formula.replace(/(\d+)/g,'<sub>$1</sub>')}</b></span><span>MW <b>${f1(p.mw)}</b></span><span>logP≈ <b>${f1(p.logp)}</b></span><span>HBD <b>${p.hbd}</b></span><span>HBA <b>${p.hba}</b></span><span>TPSA≈ <b>${f1(p.tpsa,1)}</b></span></div>`;
const verdict=p=>p.viol==0?'<span class="ok">Passes all 4 rules</span>':`<span class="${p.viol>1?'no':'ok'}">${p.viol} violation${p.viol>1?'s':''}</span>`;
const get=s=>{try{const m=parse(s);return{m,p:props(m)}}catch(e){return null}};

function studio(full,rep){return`<div class="panel"><label for="smi"><b>SMILES string</b></label><input id="smi" value="${esc(S.cur)}" spellcheck="false" autocomplete="off">
<div class="chips">${Object.keys(EX).map(k=>`<button class="ghost" data-ex="${k}">${k}</button>`).join('')}</div>
<div class="paper" id="draw"></div><div id="pills"></div>
${full?`<div class="row"><input id="nm" placeholder="Name this molecule" aria-label="Molecule name"><button id="add">Add to notebook</button></div><p class="exp" id="msg"></p>`:''}</div>`}
function upd(){const d=$('#draw');if(!d)return;try{const m=parse(S.cur),p=props(m);d.innerHTML=svg(m);$('#pills').innerHTML=pills(p);if($('#rep'))$('#rep').innerHTML=report(p)}catch(e){d.innerHTML='<p class="err">'+esc(e.message||e)+'</p>';$('#pills').innerHTML='';if($('#rep'))$('#rep').innerHTML=''}}
function bindStudio(){const i=$('#smi');if(!i)return;i.oninput=()=>{S.cur=i.value;upd()};
 document.querySelectorAll('[data-ex]').forEach(b=>b.onclick=()=>{S.cur=EX[b.dataset.ex];i.value=S.cur;if($('#nm'))$('#nm').value=b.dataset.ex;upd()});
 if($('#add'))$('#add').onclick=()=>{const g=get(S.cur);if(!g){$('#msg').textContent='Fix the SMILES string before adding it.';return}const n=$('#nm').value.trim()||'Molecule '+(S.mols.length+1);S.mols.push({n,s:S.cur});save();$('#msg').textContent=n+' added. See it on the Structure–property page.'}
 upd()}

function report(p){const r=[['Molecular formula',p.formula,'Atoms in the molecule, hydrogens included.'],['Molecular weight (Da)',f1(p.mw),'Rule of five: ≤ 500.'],['logP (estimate)',f1(p.logp),'Fat vs water preference. Rule: ≤ 5. This is a simple atom-contribution estimate.'],['H-bond donors',p.hbd,'N–H and O–H groups. Rule: ≤ 5.'],['H-bond acceptors',p.hba,'Nitrogen and oxygen atoms. Rule: ≤ 10.'],['TPSA (Å², estimate)',f1(p.tpsa,1),'Polar surface area. Below about 140 suggests good membrane permeability.'],['Rotatable bonds',p.rot,'Flexibility. Fewer than 10 is typical for oral drugs.'],['Rings / aromatic rings',p.rings+' / '+p.arom,'Ring count from the bond graph.'],['Heavy atoms',p.heavy,'All non-hydrogen atoms.']];
 return`<div class="panel wrap"><h3>Molecular properties report</h3><table><tr><th>Property</th><th>Value</th><th>What it tells you</th></tr>${r.map(x=>`<tr><td>${x[0]}</td><td><b>${x[1]}</b></td><td class="exp">${x[2]}</td></tr>`).join('')}<tr><td>Lipinski’s rule of five</td><td colspan="2">${verdict(p)}</td></tr></table></div>`}

const T=[['What is cheminformatics?','It uses computers to store, search and analyse chemical structures. Instead of drawing every molecule by hand, we describe it as data and let software calculate its properties and compare it with thousands of others.'],
['Reading a SMILES string','SMILES writes a molecule as text. Capital letters are atoms (<code>C</code>, <code>N</code>, <code>O</code>), lowercase letters are aromatic atoms (<code>c</code>), <code>=</code> and <code>#</code> are double and triple bonds, parentheses mark branches, and matching digits close rings. Benzene is <code>c1ccccc1</code>; ethanol is <code>CCO</code>.'],
['Molecular descriptors','Descriptors are numbers computed from structure: molecular weight, logP (lipophilicity), hydrogen-bond donors and acceptors, topological polar surface area (TPSA) and rotatable bonds. Each one links to how a molecule behaves in the body.'],
['Lipinski’s rule of five','Oral drugs tend to have MW ≤ 500, logP ≤ 5, no more than 5 H-bond donors and no more than 10 acceptors. More than one violation suggests poor absorption. It is a guide, not a law.'],
['Structure–property relationships','Small structural changes shift properties in predictable ways. Adding an –OH lowers logP and adds a donor; adding carbons raises logP and weight. Comparing a set of molecules side by side reveals these trends.']];
const Q=[['What does SMILES stand for?',['Simplified Molecular Input Line Entry System','Standard Molecular Isomer List','Simple Molecule Index of Linked Elements'],0,'SMILES encodes structure as a line of text.'],
['In SMILES, what does a lowercase “c” mean?',['A chlorine atom','An aromatic carbon','A charged carbon'],1,'Lowercase letters mark aromatic atoms.'],
['Which symbol writes a double bond?',['#','=','-'],1,'“=” is double, “#” is triple.'],
['What is the molecular weight limit in Lipinski’s rule of five?',['300 Da','500 Da','1000 Da'],1,'MW ≤ 500 Da.'],
['Which descriptor estimates how well a molecule dissolves in fat versus water?',['logP','Rotatable bonds','Ring count'],0,'logP is the partition coefficient between octanol and water.']];
let ans={},done=false;

const pages={
home(){return`<section class="hero"><div><h1>Learn how molecules turn into numbers.</h1><p>Type a molecule as text and watch it appear as a structure, with its weight, polarity and drug-likeness worked out instantly. Seven short modules take you from theory to a finished report.</p><div class="row"><a class="btn" href="#visualize">Open the bench</a><a class="btn ghost" style="color:var(--ink);border:1px solid var(--line);background:none" href="#theory">Read the theory first</a></div></div>${studio(false)}</section>
<div class="three">${[['Validate','Check any SMILES string and get plain-language errors.','#visualize'],['Visualise','See a 2D drawing with bonds, rings and heteroatoms.','#visualize'],['Calculate','Formula, weight, logP, donors, acceptors, TPSA and more.','#properties'],['Compare','Plot your notebook of molecules on any two properties.','#analysis'],['Test yourself','Five questions with instant feedback.','#assessment'],['Report','Compile a final report you can print or copy.','#report']].map(x=>`<a class="panel" style="text-decoration:none;color:inherit" href="${x[2]}"><h3>${x[0]}</h3><p class="exp" style="margin:0">${x[1]}</p></a>`).join('')}</div>`},
theory(){return`<h2>Theory</h2>${T.map((t,i)=>`<details class="t"${i?'':' open'}><summary>${t[0]}</summary><p>${t[1]}</p></details>`).join('')}`},
visualize(){return`<h2>Molecular visualization</h2><p class="exp">Edit the SMILES string and the drawing updates as you type.</p>${studio(true)}`},
properties(){return`<h2>Molecular properties report</h2>${studio(false)}<div id="rep" style="margin-top:16px"></div>`},
analysis(){return`<h2>Structure–property analysis</h2><p class="exp">Add molecules from the Visualization page, then compare them here.</p><div class="panel"><div class="sel"><label>X axis<select id="ax"></select></label><label>Y axis<select id="ay"></select></label></div><div class="wrap" id="plot"></div></div><div class="panel wrap" style="margin-top:16px" id="tbl"></div>`}
,assessment(){return`<h2>Assessment</h2>${Q.map((q,i)=>`<div class="q"><h3>${i+1}. ${q[0]}</h3>${q[1].map((o,j)=>`<label><input type="radio" name="q${i}" value="${j}"${ans[i]==j?' checked':''}>${o}</label>`).join('')}<div class="exp" id="e${i}"></div></div>`).join('')}<button id="sub">Check my answers</button> <button class="ghost" id="rst">Start over</button><h3 id="score" style="margin-top:18px"></h3>`},
report(){const rows=S.mols.map(x=>({x,g:get(x.s)})).filter(r=>r.g);return`<h2>Final project report</h2><div class="panel" id="rp"><h3>Cheminformatics virtual lab report</h3><p><b>Student:</b> ${esc(S.stu.n)||'(add your name above)'}<br><b>Registration number:</b> ${esc(S.stu.r)||'(add it above)'}<br><b>Date:</b> ${new Date().toLocaleDateString()}</p>
<div class="wrap"><table><tr><th>Name</th><th>SMILES</th><th>Formula</th><th>MW</th><th>logP≈</th><th>HBD</th><th>HBA</th><th>Lipinski</th></tr>${rows.map(({x,g})=>`<tr><td>${esc(x.n)}</td><td><code>${esc(x.s)}</code></td><td>${g.p.formula}</td><td>${f1(g.p.mw)}</td><td>${f1(g.p.logp)}</td><td>${g.p.hbd}</td><td>${g.p.hba}</td><td>${verdict(g.p)}</td></tr>`).join('')||'<tr><td colspan="8">No molecules yet. Add some on the Visualization page.</td></tr>'}</table></div>
<h3 style="margin-top:20px">Observations and conclusions</h3><textarea id="nt" rows="7" placeholder="Describe the trends you noticed and what they mean.">${esc(S.notes)}</textarea></div>
<div class="row noprint"><button id="pr">Print or save as PDF</button><button class="ghost" id="cp">Copy report text</button></div><p class="exp" id="cm"></p>`}};

function after(p){
 if(p=='visualize'||p=='properties'||p=='home')bindStudio();
 if(p=='analysis'){const K={mw:'Molecular weight',logp:'logP (estimate)',hbd:'H-bond donors',hba:'H-bond acceptors',tpsa:'TPSA (estimate)',rot:'Rotatable bonds'};
  const opt=v=>Object.entries(K).map(([k,n])=>`<option value="${k}"${k==v?' selected':''}>${n}</option>`).join('');$('#ax').innerHTML=opt('mw');$('#ay').innerHTML=opt('logp');
  const draw=()=>{const ax=$('#ax').value,ay=$('#ay').value,rows=S.mols.map((x,i)=>({x,i,g:get(x.s)})).filter(r=>r.g);
   if(!rows.length){$('#plot').innerHTML='<p class="exp">Your notebook is empty.</p>';$('#tbl').innerHTML='';return}
   const ex=k=>{const v=rows.map(r=>r.g.p[k]),a=Math.min(...v),b=Math.max(...v),pd=(b-a||1)*.12;return[a-pd,b+pd]},[x0,x1]=ex(ax),[y0,y1]=ex(ay),W=640,H=340,L=56,Bm=44,sx=v=>L+(v-x0)/(x1-x0)*(W-L-20),sy=v=>H-Bm-(v-y0)/(y1-y0)*(H-Bm-16);
   let o=`<svg viewBox="0 0 ${W} ${H}" style="min-width:520px;width:100%" role="img" aria-label="Scatter plot"><g stroke="var(--line)"><line x1="${L}" y1="${H-Bm}" x2="${W-20}" y2="${H-Bm}"/><line x1="${L}" y1="16" x2="${L}" y2="${H-Bm}"/></g><g fill="var(--mut)" font-size="12">`;
   for(let t=0;t<=4;t++){const vx=x0+(x1-x0)*t/4,vy=y0+(y1-y0)*t/4;o+=`<text x="${sx(vx)}" y="${H-Bm+16}" text-anchor="middle">${f1(vx,vx>20?0:1)}</text><text x="${L-6}" y="${sy(vy)+4}" text-anchor="end">${f1(vy,vy>20?0:1)}</text>`}
   o+=`<text x="${(W+L)/2}" y="${H-8}" text-anchor="middle" font-size="13">${K[ax]}</text><text transform="rotate(-90)" x="${-H/2}" y="14" text-anchor="middle" font-size="13">${K[ay]}</text></g>`;
   rows.forEach(r=>{const cx=sx(r.g.p[ax]),cy=sy(r.g.p[ay]);o+=`<circle cx="${cx}" cy="${cy}" r="7" fill="${r.g.p.viol?'var(--acc2)':'var(--acc)'}"/><text x="${cx+10}" y="${cy+4}" font-size="12" fill="currentColor">${esc(r.x.n)}</text>`});
   $('#plot').innerHTML=o+'</svg><p class="exp">Teal points pass Lipinski’s rule of five; amber points have at least one violation.</p>';
   $('#tbl').innerHTML=`<table><tr><th>Name</th><th>MW</th><th>logP≈</th><th>HBD</th><th>HBA</th><th>TPSA≈</th><th>RotB</th><th></th></tr>${rows.map(r=>`<tr><td>${esc(r.x.n)}</td><td>${f1(r.g.p.mw)}</td><td>${f1(r.g.p.logp)}</td><td>${r.g.p.hbd}</td><td>${r.g.p.hba}</td><td>${f1(r.g.p.tpsa,1)}</td><td>${r.g.p.rot}</td><td><button class="ghost" data-rm="${r.i}" aria-label="Remove ${esc(r.x.n)}">Remove</button></td></tr>`).join('')}</table>`;
   document.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{S.mols.splice(+b.dataset.rm,1);save();draw()})};
  $('#ax').onchange=$('#ay').onchange=draw;draw()}
 if(p=='assessment'){document.querySelectorAll('.q input').forEach(r=>r.onchange=()=>{ans[+r.name.slice(1)]=+r.value});
  $('#sub').onclick=()=>{let s=0;Q.forEach((q,i)=>{const ok=ans[i]==q[2];s+=ok;$('#e'+i).innerHTML=(ok?'<span class="ok">Correct.</span> ':'<span class="no">Not quite.</span> ')+q[3]});$('#score').textContent='Score: '+s+' / '+Q.length};
  $('#rst').onclick=()=>{ans={};render()}}
 if(p=='report'){$('#nt').oninput=e=>{S.notes=e.target.value;save()};
  $('#pr').onclick=()=>{try{window.print()}catch(e){$('#cm').textContent='Printing is blocked here. Use Copy report text instead.'}};
  $('#cp').onclick=async()=>{const t=['Cheminformatics Virtual Lab report','Student: '+S.stu.n,'Registration number: '+S.stu.r,'',...S.mols.map(x=>{const g=get(x.s);return g?`${x.n} (${x.s}): ${g.p.formula}, MW ${f1(g.p.mw)}, logP≈${f1(g.p.logp)}, HBD ${g.p.hbd}, HBA ${g.p.hba}, Lipinski violations ${g.p.viol}`:''}),'','Observations: '+S.notes].join('\n');
   try{await navigator.clipboard.writeText(t);$('#cm').textContent='Report copied.'}catch(e){$('#cm').textContent='Copying is blocked here. Select the report on screen and copy it manually.'}}}}
function render(){const p=(location.hash.slice(1)||'home');const pg=pages[p]?p:'home';$('#nav').innerHTML=[['home','Home'],['theory','Theory'],['visualize','Visualization'],['properties','Properties report'],['analysis','Structure–property'],['assessment','Assessment'],['report','Final report']].map(x=>`<a href="#${x[0]}"${x[0]==pg?' class="on" aria-current="page"':''}>${x[1]}</a>`).join('');
 $('#app').innerHTML=pages[pg]();after(pg);window.scrollTo(0,0)}
const sl=()=>{$('#stuL').textContent=S.stu.n?S.stu.n+(S.stu.r?' · '+S.stu.r:''):'Student details'};
$('#sn').value=S.stu.n;$('#sr').value=S.stu.r;sl();
$('#sn').oninput=e=>{S.stu.n=e.target.value;save();sl()};$('#sr').oninput=e=>{S.stu.r=e.target.value;save();sl()};
addEventListener('hashchange',render);render();
